package br.edu.unisales.horarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HorariosApplication {

    public static void main(String[] args) {
        SpringApplication.run(HorariosApplication.class, args);
    }
}
